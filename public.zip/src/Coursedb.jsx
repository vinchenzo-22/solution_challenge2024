import React from "react";

const Coursedb = [
  {
    id: 1,
    courseimage:"https://cdn.10minuteschool.com/lg/images/Thumbnails/Ghore-boshe-Spoken-English-Course-Thumbnail.jpg",
    coursetitle: "ঘরে বসে Spoken English",
    coursepara:"Some quick example text to build on the card title and make up the bulk of the card's content.",
    amount: "950",
    link: "#",
  },
  {
    id: 2,
    courseimage:"https://cdn.10minuteschool.com/lg/images/skills/Updated_Thumbnail_v3/Kids-English-Course-Thumbnail.jpg",
    coursetitle: "Kids' English",
    coursepara:"Some quick example text to build on the card title and make up the bulk of the card's content.",
    amount: "1250",
    link: "#",
  },
  {
    id: 3,
    courseimage:"https://cdn.10minuteschool.com/lg/images/skills/Updated_Thumbnail_v3/Robotics-For-Kids-Course-Thumbnail.jpg",
    coursetitle: "Robotics for Kids",
    coursepara:"Some quick example text to build on the card title and make up the bulk of the card's content.",
    amount: "1250",
    link: "#",
  },
  {
    id: 4,
    courseimage:"https://cdn.10minuteschool.com/lg/images/Thumbnails/Wedding-Photography-Course-Thumbnail.jpg",
    coursetitle: "Wedding Photography",
    coursepara:"Some quick example text to build on the card title and make up the bulk of the card's content.",
    amount: "950",
    link: "#",
  },
  {
    id: 5,
    courseimage:"https://cdn.10minuteschool.com/lg/images/Thumbnails/Cartoon-Animation-Course-Thumbnail.jpg",
    coursetitle: "Cartoon Animation",
    coursepara:"Some quick example text to build on the card title and make up the bulk of the card's content.",
    amount: "950",
    link: "#",
  },
];

export default Coursedb;
