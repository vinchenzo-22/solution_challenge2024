import React from "react";

const About = () => {
  return (
    <React.Fragment>
      <h1>Welcome to About</h1>
      <h1>Welcome to About</h1>
    </React.Fragment>
  );
};

export default About;
